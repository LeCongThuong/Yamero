/**
 * Name: Truong Hoang Giang
 * MSV: 16020928
 * Description:
 *  - Server open socket on port 9090 and waiting connection from clients
 *  - Server reveive command from client
 *  - If command inputStream "ls", server send linputStreamt of all file in folder SharedFolder for client
 *  - If command inputStream "download filename", server send file with filename in SharedFolder back to client
 *  - If command inputStream "@logout", Server close connection
 *  - Client can connect many times until server die
 **/

import java.net.*;
import java.io.*;

// thread run when receive connection from client
class ServerThread extends Thread {
    private static final int bufferSize = 1024;
    private static Socket connClientSocket;
    private static final String terminateStr = "@logout";

    public ServerThread(Socket socket) {
        connClientSocket = socket;
    }

    @Override
    public void run() {
        InputStream inputStream = null;
        InputStreamReader inputStreamReader = null;
        BufferedReader bufferedReader = null;

        OutputStream outputStream = null;
        DataOutputStream dataOutputStream = null;

        try {
            // Get info client
            InetAddress clientIpAddress = connClientSocket.getInetAddress();
            int clientPort = connClientSocket.getPort();
            String clientAddr = clientIpAddress.toString().replace("/", "") + ":" + clientPort;
            System.out.println("Client address: " + clientAddr + " connected.");

            // Input utils
            inputStream = connClientSocket.getInputStream();
            inputStreamReader = new InputStreamReader(inputStream);
            bufferedReader = new BufferedReader(inputStreamReader);

            // Output utils
            outputStream = connClientSocket.getOutputStream();
            dataOutputStream = new DataOutputStream(outputStream);

            File sharedFolder = new File("./SharedFolder");

            boolean terminate = false;
            while (!terminate) {
                // Read command
                String command = bufferedReader.readLine();
                String cmdArgs[] = command.split(" ", 2);
                switch (cmdArgs[0]) {
                    case terminateStr:
                        terminate = true;
                        break;
                    case "ls":
                        String message = "";
                        String[] files = sharedFolder.list();
                        for (String fileName : files) {
                            message += fileName + "\n";
                        }
                        dataOutputStream.writeUTF(message);
                        break;
                    case "download":
                        String fileName = cmdArgs[1].trim();
                        File file;
                        FileInputStream fileInputStream;
                        long fileSize;
                        try {
                            System.out.println("Client " + clientAddr + " request file: " + fileName);
                            file = new File("./SharedFolder/" + fileName);
                            fileInputStream = new FileInputStream(file);
                            fileSize = file.length();
                        } catch (IOException e) {
                            message = "Cannot find file '" + fileName + "'!";
                            System.out.println(message);
                            dataOutputStream.writeUTF(message);
                            break;
                        }

                        // Handle file errors
                        if (fileSize <= 0 ) {
                            message = "Cannot find file '" + fileName + "'!";
                            System.out.println(message);
                            dataOutputStream.writeUTF(message);
                            break;
                        }
                        // Send file size
                        dataOutputStream.writeUTF("@fileMeta " + fileName + " " + fileSize);
                        
                        // Send file
                        byte[] buffer = new byte[bufferSize];
                        int nBytes;
                        while ((nBytes = fileInputStream.read(buffer)) != -1) {
                            outputStream.write(buffer, 0, nBytes);
                        }
                        System.out.println("Sent file " + fileName + " successfully to client " + clientAddr);
                        outputStream.flush();
                        fileInputStream.close();
                        break;
                    default:
                        dataOutputStream.writeUTF("Command not found: " + command);
                }
            }

            System.out.println("Client address: " + clientAddr + " close connection.");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                inputStream.close();
                inputStreamReader.close();
                outputStream.close();
                bufferedReader.close();
                dataOutputStream.close();
                connClientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}

class Server {
    private final static int port = 9090;

    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(port);
            System.out.println("Server is listening at port: " + port);

            while (true) {
                Socket connClientSocket = serverSocket.accept();
                Thread multiThread = new ServerThread(connClientSocket);
                multiThread.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}