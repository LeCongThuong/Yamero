/**
 * Name: Truong Hoang Giang
 * MSV: 16020928
 * Description:
 *  - Server open socket on port 9090 and waiting connection from clients
 *  - Server reveive command from client
 *  - If command is "ls", server send linputStreamt of all file in folder SharedFolder for client
 *  - If command is "download filename", server send file with filename in SharedFolder back to client
 *  - If command is "upload filename", server receive file from client and save to SharedFolder
 *  - If command is "@logout", Server close connection
 *  - Client can send command many times until server die
 *  - Many client can connect to server at a time
 **/

import java.net.*;
import java.io.*;

// thread run when receive connection from client
class ServerThread extends Thread {
    private static final int bufferSize = 1024;
    private static Socket connClientSocket;
    private static final String terminateStr = "@logout";
    private static int receivedFileCount = 0;
    private static int sentFileCount = 0;
    private String clientAddr;

    public ServerThread(Socket socket) {
        connClientSocket = socket;
    }

    private synchronized void receiveFileSuccess() {
        receivedFileCount++;
        System.out.println("Total file receive from clients: " + receivedFileCount);
    }

    private synchronized void sendFileSuccess() {
        sentFileCount++;
        System.out.println("Total file send to clients: " + sentFileCount);

    }

    @Override
    public void run() {
        InputStream inputStream = null;
        DataInputStream dataInputStream = null;

        OutputStream outputStream = null;
        DataOutputStream dataOutputStream = null;

        try {
            // Get info client
            InetAddress clientIpAddress = connClientSocket.getInetAddress();
            int clientPort = connClientSocket.getPort();
            clientAddr = clientIpAddress.toString().replace("/", "") + ":" + clientPort;
            System.out.println("Client address: " + clientAddr + " connected.");

            // Input utils
            inputStream = connClientSocket.getInputStream();
            dataInputStream = new DataInputStream(inputStream);

            // Output utils
            outputStream = connClientSocket.getOutputStream();
            dataOutputStream = new DataOutputStream(outputStream);

            File sharedFolder = new File("./SharedFolder");

            boolean terminate = false;
            while (!terminate) {
                // Read command
                String command = dataInputStream.readUTF();
                String cmdArgs[] = command.split(" ", 2);
                switch (cmdArgs[0]) {
                    case terminateStr:
                        terminate = true;
                        break;
                    case "ls":
                        String message = "";
                        String[] files = sharedFolder.list();
                        for (String fileName : files) {
                            message += fileName + "\n";
                        }
                        dataOutputStream.writeUTF(message);
                        break;
                    case "download":
                        String fileName = cmdArgs[1].trim();
                        File file;
                        FileInputStream fileInputStream;
                        long fileSize;
                        try {
                            System.out.println("Client " + clientAddr + " request file: " + fileName);
                            file = new File("./SharedFolder/" + fileName);
                            fileInputStream = new FileInputStream(file);
                            fileSize = file.length();
                        } catch (IOException e) {
                            message = "Cannot find file '" + fileName + "'!";
                            System.out.println(message);
                            dataOutputStream.writeUTF(message);
                            break;
                        }

                        // Handle file errors
                        if (fileSize <= 0 ) {
                            message = "Cannot find file '" + fileName + "'!";
                            System.out.println(message);
                            dataOutputStream.writeUTF(message);
                            break;
                        }
                        // Send file meta data
                        dataOutputStream.writeUTF("@fileMeta " + fileName + " " + fileSize);
                        
                        // Send file
                        byte[] buffer = new byte[bufferSize];
                        int nBytes;
                        while ((nBytes = fileInputStream.read(buffer)) != -1) {
                            outputStream.write(buffer, 0, nBytes);
                        }
                        System.out.println("Sent file " + fileName + " successfully to client " + clientAddr);
                        outputStream.flush();
                        fileInputStream.close();
                        sendFileSuccess();
                        break;
                    case "upload":
                        // Get file meta data
                        String fileMeta = dataInputStream.readUTF();
                        String meta[] = fileMeta.split(" ", 3);
                        fileName = meta[1].trim();
                        fileSize = Long.parseLong(meta[2].trim());
                        // Receive file
                        FileOutputStream fileOutputStream = new FileOutputStream("./SharedFolder/" + fileName);
                        buffer = new byte[bufferSize];
                        long totalBytesRead = 0;
                        while (totalBytesRead < fileSize) {
                            nBytes = dataInputStream.read(buffer);
                            fileOutputStream.write(buffer, 0, nBytes);
                            totalBytesRead += nBytes;
                        }
                        System.out.println("Receive file " + fileName + " from " + clientAddr + " successfully.");
                        fileOutputStream.close();
                        receiveFileSuccess();
                        break;
                    default:
                        dataOutputStream.writeUTF("Command not found: " + command);
                }
            }

            System.out.println("Client address: " + clientAddr + " close connection.");
        } catch (IOException e) {
            System.out.println("Client " + clientAddr + " lose connection!");
        } finally {
            try {
                inputStream.close();
                dataInputStream.close();
                outputStream.close();
                dataOutputStream.close();
                connClientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}

class Server {
    private final static int port = 9090;

    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(port);
            System.out.println("Server is listening at port: " + port);

            while (true) {
                Socket connClientSocket = serverSocket.accept();
                Thread multiThread = new ServerThread(connClientSocket);
                multiThread.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}