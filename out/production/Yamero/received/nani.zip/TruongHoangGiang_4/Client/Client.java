/**
 * Name: Truong Hoang Giang
 * MSV: 16020928
 * Description:
 *  - Client connect to Server on port 9090
 *  - Client receive command from user and send to server
 *  - If command is "ls", server send list of all file in folder SharedFolder for client
 *  - If command is "download filename", server send file with filename in SharedFolder back to client
 *  - If command is "upload filename", client send file from SharedFolder to server
 *  - If command is "@logout", Client close connection
 *  - Client can connect many times until server die
 *  - Many client can connect to server at a time
 **/

import java.net.*;
import java.io.*;
import java.util.Scanner;

class Client {
    private static final String terminateStr = "@logout";
    private static final int bufferSize = 1024;
    private static Scanner scanner = new Scanner(System.in);
    private static Socket serverSocket;
    private static String ipAddress;
    private static final int port = 9090;


    public static void main(String[] args) {
        InputStream inputStream = null;
        DataInputStream dataInputStream = null;

        OutputStream outputStream = null;
        DataOutputStream dataOutputStream = null;

        try {
            System.out.print("Server IP Address: ");
            ipAddress = scanner.nextLine();
            InetAddress address = InetAddress.getByName(ipAddress);
            serverSocket = new Socket(address, port);

            // Input utils
            inputStream = serverSocket.getInputStream();
            dataInputStream = new DataInputStream(inputStream);

            // Output utils
            outputStream = serverSocket.getOutputStream();
            dataOutputStream = new DataOutputStream(outputStream);

            boolean isLogout = false;

            while (!isLogout) {
                // Enter command
                System.out.println("Enter 'ls' to list file, 'download filename' to download, 'upload filename' to upload and '@logout' to close connection.");
                System.out.print("Command: ");

                String command;                
                if (scanner.hasNextLine()) {
                    command = scanner.nextLine().trim();
                } else {
                    break;
                }

                String cmdArgs[] = command.split(" ", 2);
                switch (cmdArgs[0]) {
                    // handle @logout
                    case terminateStr:
                        // Send command
                        dataOutputStream.writeUTF(command);
                        isLogout = true;
                        break;
                    case "download":
                        // Send command
                        dataOutputStream.writeUTF(command);

                        // Get file meta data
                        String fileMeta = dataInputStream.readUTF();
                        String meta[] = fileMeta.split(" ", 3);
                        if (meta[0].equals("@fileMeta")) { // file meta data message has form of '@fileMeta filename 12345'
                            String fileName = meta[1].trim();
                            long fileSize = Long.parseLong(meta[2].trim());
                            // Download file
                            FileOutputStream fileOutputStream = new FileOutputStream(fileName);
                            byte[] buffer = new byte[bufferSize];
                            long totalBytesRead = 0;
                            while (totalBytesRead < fileSize) {
                                int nBytes = dataInputStream.read(buffer);
                                fileOutputStream.write(buffer, 0, nBytes);
                                totalBytesRead += nBytes;
                            }
                            System.out.println("Download file " + fileName + " successfully.");
                            fileOutputStream.close();
                        } else {
                            System.out.println(fileMeta); // smt went wrong in server and it send error back
                        }
                        break;
                    case "upload":
                        String fileName = cmdArgs[1].trim();
                        File file;
                        FileInputStream fileInputStream;
                        long fileSize;
                        try {
                            file = new File("./SharedFolder/" + fileName);
                            fileInputStream = new FileInputStream(file);
                            fileSize = file.length();
                        } catch (IOException e) {
                            System.out.println("Cannot find file '" + fileName + "'!");
                            break;
                        }
                        // Send command
                        dataOutputStream.writeUTF(command);
                        // Send file meta data
                        dataOutputStream.writeUTF("@fileMeta " + fileName + " " + fileSize);
                        // Send file
                        byte[] buffer = new byte[bufferSize];
                        int nBytes;
                        while ((nBytes = fileInputStream.read(buffer)) != -1) {
                            outputStream.write(buffer, 0, nBytes);
                        }
                        System.out.println("Upload file " + fileName + " successfully to Server!");
                        outputStream.flush();
                        fileInputStream.close();
                        break;
                    default:
                        // handle ls command or some wrong command
                        // Send command
                        dataOutputStream.writeUTF(command);

                        String message = dataInputStream.readUTF();
                        System.out.println(message);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (!serverSocket.isClosed()) {
                    serverSocket.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
}